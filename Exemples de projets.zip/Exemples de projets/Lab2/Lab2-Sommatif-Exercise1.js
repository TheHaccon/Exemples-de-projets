let montant = 10;

const interet = 1940059 * 0.00000002;
const annee = 20;
const nbdepot = 12;

let depot = 20;
investissement
let investissementActuel = 1;


for(let anneeCourante=1;anneeCourante<annee+1;anneeCourante++)
{for(let depotCourant=1; depotCourant<nbdepot+1;depotCourant++){
    if(depotCourant %2 == 0)
    {
        Crediter(depot * 10 * depotCourant * anneeCourante);
    }

    if(depotCourant %2 != 0)
    {
        Crediter(depot*-10*depotCourant*anneeCourante) = montant;
    }
    console.log("Année : ",anneeCourante,", Dépot :",depotCourant,", Montant : ",montant);
}
}

function Crediter(depot, investissementActuel){
    var depot =20;
    var investissementActuel = 0;


   var inv investissementActuel + depot;

    if(investissementActuel  + depot < 0)

    console.log("Le montant est négatif et il est de ", investissementActuel );

   

    return investissementActuel ;



}



function CalculInterets(investissement){

    investissementActuel  = investissement*tauxInteret;

    return investissementActuel ;

}
CalculInterets(investissement);
