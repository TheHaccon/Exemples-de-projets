function reverse(string) {
    var o = '';
    for (var i = string.length - 1; i >= 0; i--)
      o += string[i];
    return o;
  }
function palindrome(string){
    const longeurString = string.length;

    for(let i=0;i<longeurString / 2; i++){
        if(reverse(string) !== string){
            return "pas un mot palindrome";
        }
        return "mot palindrome";
    }
}
const string = prompt("entré un mot : ");
const reponse = palindrome(string);
console.log(reponse);
