let combinaisonGagnante;
let combinaison = [];
let montantTotal = 0;


const nbrCombinaison = 10;
const nbrParticipant = 1000;

function GenererCombinaison()
{
    let croissant = [];
    for(let i=0;i<nbrCombinaison;i++)
    croissant[i] = Math.floor(Math.random()*100+1);

    croissant.sort(function(a,b)
    {
        return a -b;
    });
    return croissant;
}
combinaisonGagnante = GenererCombinaison();
console.log(combinaisonGagnante);

for(let i=0;i<nbrParticipant;i++)
{
combinaison[i] = GenererCombinaison();

}
function CalculNombreIdentique(combinaison,combinaisonGagnante)
{
    let bagel=0;
    for(let i=0;i<combinaison.length;i++)
    {
        if(combinaison.indexOf(combinaisonGagnante[i])!= -1)
        {
            bagel ++;
        }

    }
    return bagel;
}

let resultat;
for(let i=0;i<combinaison.length;i++)
{
    resultat = CalculNombreIdentique(combinaison[i], combinaisonGagnante);
    if(resultat > nbrCombinaison -3)
    {
        console.log("Bravo! vous avez gagnez 10000$" + combinaison[i]);
        montantTotal += 10000; 
    }
    if(resultat > (nbrCombinaison/2 )-1 && resultat< nbrCombinaison-2)
    {
        console.log("Bravo! vous avez gagnez 500$" + combinaison[i]);
        montantTotal +=500;
    }
    if(i == combinaison.length -1)
    console.log("montant total gagné : "+ montantTotal)


}
