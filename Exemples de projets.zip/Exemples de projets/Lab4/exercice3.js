let element1 = document.querySelector("body");
//changement de font
element1.style.fontFamily = "Arial,sans-serif";


//remplaced text
let element2 =document.querySelector("#name");
element2.textContent = "Mathis Côté";
let element3 =document.querySelector("#favorites");
element3.textContent = "Programmation";
let element4 =document.querySelector("#city");
element4.textContent = "G-town";

//boucle
let element5 = document.getElementsByTagName("li");
for(let i=0;i<element5.length;i++)
{
    element5[i].classList.add ("Listitem");    
}
for(let i=0;i<element5.length;i++)
{
    element5[i].style.color = "red";
}
//image
let element6 = document.createElement("img");
element1.insertAdjacentElement("beforeend",element6);
element6.setAttribute("src","http://gotocon.com/dl/jaoo_aus2008/photos/speakers/Pamela_Fox.jpg");

let element7 = document.createElement("img");
element1.insertAdjacentElement("beforebegin",element7);
element7.setAttribute("src","http://gotocon.com/dl/jaoo_aus2008/photos/speakers/Pamela_Fox.jpg");