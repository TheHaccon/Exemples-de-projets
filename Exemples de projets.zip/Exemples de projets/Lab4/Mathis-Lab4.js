//creation du bouton rouge
let element1 = document.querySelector(".acces");
let element2 = document.createElement("btn");
element2.className = "btn btn-danger my-2";
element2.innerHTML ="Troisième action";
element1.appendChild(element2);

//creation du lien LaPresse
let header = document.querySelector(".list-unstyled");
let newli = document.createElement("li");
let a =document.createElement("a");
a.text ="Suivez-moi sur LaPresse";
newli.appendChild(a);
a.href = "https://www.lapresse.ca/";
a.classList.add("text-white");
header.appendChild(newli);

//mettre en vert une card
let card = document.querySelector(".card");
let cardBody = document.querySelector(".card-body");
cardBody.classList.add("bg-success");

//modification du text poue mettre mon nom
let nom = document.querySelector(".lft");
nom.textContent= "Mathis Côté";
