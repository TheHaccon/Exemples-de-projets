let div = document.createElement("div");
document.getElementById("main").appendChild(div);
let text = 