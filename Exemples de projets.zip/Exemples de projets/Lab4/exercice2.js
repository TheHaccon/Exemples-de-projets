let element1=document.getElementById("output");
let element2 = element1.getElementsByTagName("a");
//element2[0].setAttribute("href","http://google.com");


let element3 = document.querySelector("a");
element3.setAttribute("href","http://google.com");