let element1 = document.getElementById("container");
let element2 = document.querySelector("#container");
let element3 = document.querySelectorAll("second");
let element4 = document.querySelector("ol > .third");
let element5 = document.querySelector(".footer");
element5.classList.add("main");
let element6 = document.querySelector(".footer");
element6.classList.remove("main");
let element7 = document.createElement("li");
element7.textContent ="four";
element7.setAttribute("class","four");
let element8 = element2.querySelector("ul");
element8.appendChild(element7);
let element9 = document.querySelectorAll("li");
for(let i=0;i<element9.length;i++)
{
    element9[i].style.backgroundColor ="green";
}
element1.insertAdjacentHTML("beforeend","Bonjour!");
element5.remove();
console.log(element1);
console.log(element2);
console.log(element3);
console.log(element4);
console.log(element5);
console.log(element6);
console.log(element7);
console.log(element8);
console.log(element9);
